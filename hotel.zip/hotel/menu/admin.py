from django.contrib import admin
from menu.models import MenuTable,CartTable

# Register your models here.
class MenuAdmin(admin.ModelAdmin):
    list_display = ['id','name','price','details','category','is_active','image']


admin.site.register(MenuTable,MenuAdmin)
admin.site.register(CartTable)