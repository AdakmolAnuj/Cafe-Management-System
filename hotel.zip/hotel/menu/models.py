from django.db import models
from django.contrib.auth.models import User
from django.contrib import messages




# Create your models here.
class MenuTable(models.Model):
    CATEGORIES = ((1,'Burger')),((2,'Pizza')),((3,'Friese')),((4,'Chinese'))
    name = models.CharField(max_length=50)
    price = models.FloatField()
    details = models.CharField(max_length=150)
    category = models.IntegerField(choices=CATEGORIES)
    is_active = models.BooleanField()
    image=models.ImageField(upload_to='image')


    def __str__(self) :
        return self.name + "added to table"
    
class CustomerDetails(models.Model):
   uid = models.ForeignKey(User,on_delete = models.CASCADE,db_column="uid")
   first_name = models.CharField(max_length=50)
   last_name = models.CharField(max_length=50)
   phone = models.CharField(max_length=50)
   email = models.EmailField(max_length=50)

class CartTable(models.Model):
   #when you do mm without db_column attribute, you will get column name as uid_id not just uid.
   #in uid_id, id is name of PK  column of User model. if you dont want uid_id then just add
   #db_column attribute
    uid = models.ForeignKey(User,on_delete = models.CASCADE,db_column="uid")
    pid= models.ForeignKey(MenuTable,on_delete = models.CASCADE,db_column="pid") 
    quantity = models.IntegerField(default=1)   

class OrderTable(models.Model):
   order_id=models.CharField(max_length=50)
   uid = models.ForeignKey(User,on_delete = models.CASCADE,db_column="uid")
   pid= models.ForeignKey(MenuTable,on_delete = models.CASCADE,db_column="pid") 
   quantity = models.IntegerField()    
     
