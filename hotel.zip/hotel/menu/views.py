from django.shortcuts import render,redirect
from menu.models import MenuTable,CartTable
from django.http import HttpResponse
from django.db.models import Q
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from menu.models import CustomerDetails
from django.contrib import messages




# Create your views here.
def index (request):
    data={}
    fetched_menus=MenuTable.objects.filter(is_active=True)
    data['menus']=fetched_menus
    user_id=request.user.id
    id_specific_cartitems=CartTable.objects.filter(uid=user_id)
    count=id_specific_cartitems.count()
    data['cart_count']=count
    return render(request,'menu/index.html',context=data)
    

def about (request):
   return render(request,'menu/about.html',)

def booktable (request):
   return render(request,'menu/booktable.html',)


def filter_by_category(request,category_value):
    data={}
    q1 = Q(is_active=True)
    q2 = Q(category=category_value)
    filtered_menus=MenuTable.objects.filter(q1 & q2)
    data['menus']=filtered_menus
    return render(request,'menu/index.html',context=data)

def register_user(request):
   data={}
   if request.method=="POST":
      uname=request.POST['username']
      upass=request.POST['password']
      uconf_pass=request.POST['password2']
      #implementing validation
      if (uname=='' or upass =='' or uconf_pass ==''):
         data['error_msg']='Fields can\'t be empty'
         return render(request,'user/register.html',context=data)
      elif(upass!=uconf_pass):
         data['error_msg']='Password and confirm password do not match'
         return render(request,'user/register.html',context=data)
      elif(User.objects.filter(username=uname).exists()):
         data['error_msg']=uname + ' already exists'
         return render(request,'user/register.html',context=data)
      else:
         user=User.objects.create(username=uname)
         # here username and password are column names present inside auth_user table
         user.set_password(upass)  # encrypting password
         user.save()  # saving data into table
         customer=CustomerDetails.objects.create(uid=user)
         customer.save()
         # return HttpResponse("Registration done") 
         return redirect('/user/login')
   return render(request,'user/register.html')


def login_user(request):
   data={}
   if request.method=="POST":
      uname=request.POST['username']
      upass=request.POST['password']
      # implementing validation
      if (uname=='' or upass ==''):
         data['error_msg']='Fields can\'t be empty'
         return render(request,'user/login.html',context=data)
      elif(not User.objects.filter(username=uname).exists()):
         data['error_msg']=uname + ' user is not registered'
         return render(request,'user/login.html',context=data)
      else:
         # from django.contrib.auth import authenticate
         user=authenticate(username=uname,password=upass)
         print(user)
         if user is not None:
            login(request,user)
            return redirect('/menu/index')
         else:
            data['error_msg']='Wrong Password'
            return render(request,'user/login.html',context=data)   
   return render(request,'user/login.html')

def user_logout(request):
   logout(request)
   return redirect('/menu/index')

def add_to_cart(request,pid):
   if request.user.is_authenticated:
      uid = request.user.id
      print("user id = " ,uid)
      print("menu id = ", pid)
      #we cant pass only id in cart table, it is expecting object of User and Product
      #therefore below line will gives error
      #cart=CartTable.objects.create(pid=pid,uid=uid)
      user=User.objects.get(id=uid)
      product=MenuTable.objects.get(id=pid)

      q1=Q(uid=uid)
      q2=Q(pid=pid)
      available_manu=CartTable.objects.filter(q1 & q2)
      print()
      if (available_manu.count()>0):
         messages.error(request,"Dish is Allready in Order")
         return redirect('/menu/index')
      else:
         cart=CartTable.objects.create(pid=product,uid=user)
         cart.save()
         messages.success(request,"Dish is Succesfully added to Order.")
         return redirect('/menu/index')
   else:
      return ('/user/login')

def view_cart(request):
   data={}
   user_id=request.user.id
   user=User.objects.get(id = user_id)
   id_specific_cartitems=CartTable.objects.filter(uid=user_id)
   data['menu']=id_specific_cartitems
   data['user']=user
   count=id_specific_cartitems.count()
   #data['cart_count']=count
   total_price=0
   total_quantity=0
   for item in id_specific_cartitems:
      #total_price+=item.pid.price
      total_price=(total_price+item.pid.price)*(item.quantity)
      total_quantity+=item.quantity
   data['total_price']=total_price   
   data['cart_count']=total_quantity
   return render(request,'menu/cart.html',context=data)   

def remove_item(request,cartid):
   cart=CartTable.objects.get(id=cartid)
   cart.delete()
   return redirect('/menu/view_cart')

def update_quantity(request,flag,cartid):
   cart=CartTable.objects.filter(id=cartid)
   actual_quantity = cart[0].quantity
   if(flag=="1"):
      cart.update(quantity = actual_quantity+1)
      pass
   else:
      if(actual_quantity>1):
         cart.update(quantity = actual_quantity-1)
      pass
   return redirect('/menu/view_cart')

def place_order(request):
   data ={}
   user_id=request.user.id
   user=User.objects.get(id = user_id)
   id_specific_cartitems=CartTable.objects.filter(uid=user_id)
   #customer = CustomerDetails.objects.get(uid = user_id)
   #data['customer']=customer
   data['products']=id_specific_cartitems
   data['user']=user
   total_price = 0
   total_quantity=0
   for item in id_specific_cartitems:
      total_price=(total_price+item.pid.price)*(item.quantity)
      total_quantity+=item.quantity
   data['total_price']=total_price
   data['cart_count']=total_quantity
   return render(request,'menu/order.html',context=data)

import razorpay   
def make_payment(request):
    #getting total amount
   user_id=request.user.id
   id_specific_cartitems=CartTable.objects.filter(uid=user_id)
   total_price = 0
   for item in id_specific_cartitems:
      total_price=(total_price+item.pid.price)*(item.quantity) 
       
   client = razorpay.Client(auth=("rzp_test_ls3ufyYec3WWtv", "Cm3iRE0s8JpvOE5hTg9dS8tP"))
   data = { "amount": total_price*100, "currency": "INR", "receipt": "order_rcptid_11" }
   payment = client.order.create(data=data)
   print(payment)
   #return HttpResponse("Payment Done")
   return render(request,'menu/pay.html',context=data)


       
  
